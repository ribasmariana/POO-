import java.time.LocalDate;

public class DocumentoMain {
    public static void main(String [] args){
        Documento doc1 = new Documento();

        doc1.codigo = 12345;
        doc1.nome = "Marta";
        doc1.foto = "Img1.png";
        doc1.dataNasc = LocalDate.of(1986, 12, 15);

        System.out.println(doc1);
    }
}
