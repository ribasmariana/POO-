import java.time.LocalDate;

public class Documento {
    String foto;
    String nome;
    Integer codigo;
    LocalDate dataNasc;
}
