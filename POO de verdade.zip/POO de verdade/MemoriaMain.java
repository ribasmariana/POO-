public class MemoriaMain {
    public static void main(String[]args){
        Documento doc1 = new Documento();
        doc1.nome = "Alfredo";
        Documento doc2 = doc1;
        doc2.nome="Juliana";

        System.out.println(doc1);
        System.out.println(doc2);
    }
}
