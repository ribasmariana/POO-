import java.math.BigDecimal;

public class BDecimal {
    public static void main(String []ags){
        BigDecimal bigDecimal = BigDecimal.valueOf(2.8989);
        System.out.println(bigDecimal);

        System.out.println();

        System.out.println("Subtração");
        BigDecimal subtracao = BigDecimal.valueOf(2.00).subtract(BigDecimal.valueOf(1.2));
        System.out.println("Resultado: " + subtracao);

        System.out.println();

        System.out.println("Soma");
        BigDecimal soma = BigDecimal.valueOf(2.00).add(BigDecimal.valueOf(1.2));
        System.out.println("Resultado: " + soma);

        System.out.println();

        System.out.println("Divisão");
        BigDecimal div = BigDecimal.valueOf(56.00).divide(BigDecimal.valueOf(4));
        System.out.println("Resultado: " + div);

        System.out.println();

        System.out.println("Multiplicação");
        BigDecimal mult = BigDecimal.valueOf(56.00).multiply(BigDecimal.valueOf(4));
        System.out.println("Resultado: " + mult);

        System.out.println();

        System.out.println("Potenciação");
        BigDecimal pot = BigDecimal.valueOf(56.00).pow(2);
        System.out.println("Resultado: " + pot);

        System.out.println();

        System.out.println("Máximo");
        System.out.println(new BigDecimal(2).max(new BigDecimal(8)));

        System.out.println("Mínimo");
        System.out.println(new BigDecimal(12).min(new BigDecimal(89)));

        System.out.println("Compara");
        System.out.println(new BigDecimal(29).compareTo(new BigDecimal(58)));

        System.out.println();

        System.out.println("ARREDONDAMENTO");
        System.out.println(bigDecimal.setScale(2, BigDecimal.ROUND_UP));
        System.out.println(bigDecimal.setScale(3, BigDecimal.ROUND_DOWN));


    }
}
