import java.time.LocalDate;
import java.util.ArrayList;

public class dataAniversario {
    public static void main(String[]args){
        ArrayList<LocalDate> localDateArrayList = new ArrayList <LocalDate>();


        localDateArrayList.add(LocalDate.of(1995, 7, 29));
        localDateArrayList.add(LocalDate.of(2001, 8, 30));
        localDateArrayList.add(LocalDate.of(1983, 1, 28));
        localDateArrayList.add(LocalDate.of(1990, 8, 2));
        localDateArrayList.add(LocalDate.of(2004, 1, 17));
        localDateArrayList.add(LocalDate.of(1995, 6, 27));
        localDateArrayList.add(LocalDate.of(1997, 3, 7));
        localDateArrayList.add(LocalDate.of(2002, 8, 18));
        localDateArrayList.add(LocalDate.of(2000, 2, 2));
        localDateArrayList.add(LocalDate.of(1994, 3, 16));

        LocalDate maisNovo = localDateArrayList.get(0);
        LocalDate maisVelho = localDateArrayList.get(0);

        for (LocalDate dataAtual: localDateArrayList){
            if (dataAtual.isAfter(maisNovo)){
                maisNovo = dataAtual;
            }
            if (dataAtual.isBefore(maisVelho)){
                maisVelho = dataAtual;
            }}

        System.out.println("O objeto mais novo é: " + maisNovo);
        System.out.println("O objeto mais velho é: " + maisVelho);

    }
}

