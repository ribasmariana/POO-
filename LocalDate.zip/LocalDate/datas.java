import java.time.LocalDate;
import java.time.LocalDateTime;

public class datas {
    public static void main(String[]args){
        System.out.println(LocalDate.now());
        System.out.println(LocalDateTime.now());

        LocalDate dataDeHoje = LocalDate.now();

        System.out.println();

        System.out.println("É um ano bissexto: " + dataDeHoje.isLeapYear());

        System.out.println();

        System.out.println("Que dia foi a 3 dias atrás?");
        System.out.println("Resposta: " + dataDeHoje.minusDays(3));

        System.out.println();

        System.out.println("Que dia foi a 2 meses atrás?");
        System.out.println("Resposta: " + dataDeHoje.minusMonths(2));

        System.out.println();

        System.out.println("Que dia será em 8 dias?");
        System.out.println("Resposta: " + dataDeHoje.plusDays(8));

        System.out.println();

        System.out.println("Que dia será em 4 meses?");
        System.out.println("Resposta: " + dataDeHoje.plusMonths(4));

        System.out.println();

        System.out.println("Que dia da semana é hoje?");
        System.out.println("Resposta: " + dataDeHoje.getDayOfWeek());

        System.out.println();

        LocalDate diaPgto = LocalDate.of(2022, 8, 26);
        LocalDate diaBoleto = LocalDate.of(2022, 8, 22);

        System.out.println(diaBoleto.isAfter(diaPgto));
        System.out.println(diaBoleto.isBefore(diaPgto));
    }
}
