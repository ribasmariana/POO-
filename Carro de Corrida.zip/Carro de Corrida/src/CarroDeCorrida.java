public class CarroDeCorrida {
    String identificacao;
    Double velocidadeA;
    Double velocidadeM;

    void ligar(){
        System.out.println("Vruuuuummmmm");
    }

    void desligar(){
        System.out.println("Mmmmmmmm");
    }

    void acelerar(){
        velocidadeA +=10.00;
        if (velocidadeA>velocidadeM){
            velocidadeA = velocidadeM;
        }
    }

    void frear(Integer intensidadeFreada){
        if (intensidadeFreada > 100){
            intensidadeFreada = 100;
        }else if(intensidadeFreada<0){
            intensidadeFreada = 0;
        }
        velocidadeA -= intensidadeFreada * 0.25;

        if(velocidadeA<0){
            velocidadeA = 0.00;
        }
    }

}
