public class CarroMain {
    public static void main(String [] args){

        CarroDeCorrida f144 = new CarroDeCorrida();
        f144.identificacao = "#44 LH";
        f144.velocidadeA = 0.00;
        f144.velocidadeM = 321.6;

        f144.ligar();

        System.out.println(f144.velocidadeA);

        f144.acelerar();
        System.out.println(f144.velocidadeA);

        f144.acelerar();
        System.out.println(f144.velocidadeA);

        f144.acelerar();
        System.out.println(f144.velocidadeA);

        f144.frear(20);
        System.out.println(f144.velocidadeA);

        f144.desligar();
    }
}
