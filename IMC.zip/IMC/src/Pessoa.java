public class Pessoa {

    String nome;
    Double altura;
    Double peso;
    String indice = "";

    //public  void getImc() {
    //double imc = peso / (altura * altura);
    //System.out.println(imc); DESSA FORMA É IMPRESSO O RESULTADO, NÃO SENDO POSSÍVEL ALTERAR NO MAIN

    // if (imc<=18.5){
    //     indice = "ABAIXO DO PESO";
    // }else if((imc>=18.6) &&(imc<=24.9)){
    //    indice = "PESO NORMAL";
    //    }else if((imc>=25) && (imc<=29.9)){
    //        indice = "SOBREPESO PRÉ-OBESIDADE";
    //    }else if((imc>=30) && (imc<=34.9)){
    //        indice = "OBESIDADE GRAU 1";
    //    }else if((imc>=35) && (imc<=39.9)){
    //        indice = "OBESIDADE GRAU 2";
    //    }else if(imc>=40) {
    //        indice = "OBESIDADE GRAU 3";
    //    }}

    public Double getImc() {
        double imc = peso / (altura * altura);
        return imc;
    } // GET SÓ É USADO PARA RETORNAR RESULTADOS/VALORES, NO MAIN É PRECISO DAR UM "SOUT" PARA DECLARAR

     String getGrauImc(Double imc){
         if (imc<=18.5){
             return "ABAIXO DO PESO";
         }else if((imc>=18.6) &&(imc<=24.9)){
             return "PESO NORMAL";
         }else if((imc>=25) && (imc<=29.9)){
             return "SOBREPESO PRÉ-OBESIDADE";
         }else if((imc>=30) && (imc<=34.9)){
             return "OBESIDADE GRAU 1";
         }else if((imc>=35) && (imc<=39.9)){
             return "OBESIDADE GRAU 2";
         }else {
             return "OBESIDADE GRAU 3";
         }}

    public void academia(){
        peso = peso -1;
        System.out.println("Novo peso de " + nome + " é: " + peso);
    }

    public void churrascaria(){
        peso = peso +2;
        System.out.println("Novo peso de " + nome + " é: " + peso);
    }

    public void lipo(){
        peso = peso -20;
        System.out.println("Novo peso de " + nome + " é: " + peso);
    }
}
