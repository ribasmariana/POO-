public class PessoaMain {

    public static void main(String [] args){
        Pessoa pessoa = new Pessoa();

        pessoa.nome = "Mariana Ribas";
        pessoa.altura = 1.55;
        pessoa.peso = 56.6;

//        pessoa.getImc();
//        System.out.println(pessoa.indice);
//        pessoa.academia();
//        pessoa.churrascaria();
//        pessoa.academia();
//        pessoa.lipo();

//        pessoa.getImc();
//        System.out.println(pessoa.getImc());

        String grauImc = pessoa.getGrauImc(pessoa.getImc());
        System.out.println(grauImc);

        System.out.println("A pessoa " + pessoa.nome + " tem o IMC "+ pessoa.getImc()+" com grau " + grauImc);
    }
}
