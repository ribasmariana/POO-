import java.time.LocalDate;
import java.util.Map;
import java.util.List;

public class classeAluno {
        String nome;
        Integer codigo;
        LocalDate dataNasc;
        String contato;
        String cpf;
        String email;
        String curso;
        Map<String, List<Integer>> disciplinaNotas;
    }