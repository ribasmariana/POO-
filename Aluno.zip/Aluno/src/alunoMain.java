import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class alunoMain {
    public static void main(String [] args){
        classeAluno alunos = new classeAluno();
        Map<String, List<Integer>>disciplinas = new HashMap<>();
        List<Integer>notasMat = new ArrayList<>();

        alunos.nome = "Mariana Ribas";
        alunos.codigo = 1;
        alunos.dataNasc = LocalDate.of(2002, 8, 18);
        alunos.contato = "48 998019475";
        alunos.cpf = "123.456.789-90";
        alunos.email = "mariana.ribas@gmail.com";
        alunos.curso = "TI";

        notasMat.add(10);
        notasMat.add(7);

        System.out.println(alunos);
        }
}
